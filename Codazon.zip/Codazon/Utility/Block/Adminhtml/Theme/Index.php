<?php


namespace Codazon\Utility\Block\Adminhtml\Theme;

class Index extends \Codazon\ThemeOptions\Block\Adminhtml\Themes
{


}
