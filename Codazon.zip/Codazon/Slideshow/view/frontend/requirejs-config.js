/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        "*": {
            "owlSlider": "Codazon_Slideshow/js/owl.carousel.min"
        }
    },    
    "shim": {
    	"Codazon_Slideshow/js/owl.carousel.min": ["jquery"]
    }
};