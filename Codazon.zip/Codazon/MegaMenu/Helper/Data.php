<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * CatalogRule data helper
 */
namespace Codazon\MegaMenu\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	public function addBodyClass()
	{
		echo "AAAAAAAAAAAAAAAAAAAAAA";
	}
}
